NinjaScan_GUI
=============

Ninja Scan GUI software including Sylphide format parser, 

version
----
1.1.1 2015/01/01 
	Fix 3D Cube invisible problem
	Make runnable with .Net4.0 Client. It can run on WinXp
	cleaning code
1.1.0 2014/09/14 add a function which output GPS csv file
1.0.2 2014/04/30 fix COM Port Refresh action
1.0.1 2014/04/10 fix magnetic sensor csv file error
1.0.0 2014/03/12 first release
